/*
  # Initial Schema Setup for Doctor Shift Calendar

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key)
      - `email` (text)
      - `full_name` (text)
      - `created_at` (timestamp)
    
    - `shifts`
      - `id` (uuid, primary key)
      - `date` (date)
      - `shift_type` (text)
      - `doctor_id` (uuid, references profiles)
      - `created_at` (timestamp)
    
    - `shift_swap_requests`
      - `id` (uuid, primary key)
      - `requesting_doctor_id` (uuid, references profiles)
      - `requested_doctor_id` (uuid, references profiles)
      - `shift_id` (uuid, references shifts)
      - `status` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated access
*/

-- Create profiles table
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id),
    email TEXT NOT NULL,
    full_name TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Create shifts table
CREATE TABLE shifts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE NOT NULL,
    shift_type TEXT NOT NULL CHECK (shift_type IN ('morning', 'night')),
    doctor_id UUID REFERENCES profiles(id),
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Create shift swap requests table
CREATE TABLE shift_swap_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    requesting_doctor_id UUID REFERENCES profiles(id),
    requested_doctor_id UUID REFERENCES profiles(id),
    shift_id UUID REFERENCES shifts(id),
    status TEXT NOT NULL CHECK (status IN ('pending', 'accepted', 'rejected')) DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE shifts ENABLE ROW LEVEL SECURITY;
ALTER TABLE shift_swap_requests ENABLE ROW LEVEL SECURITY;

-- Policies for profiles
CREATE POLICY "Users can read all profiles"
    ON profiles FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Users can update their own profile"
    ON profiles FOR UPDATE
    TO authenticated
    USING (auth.uid() = id);

-- Policies for shifts
CREATE POLICY "Users can read all shifts"
    ON shifts FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Users can update their own shifts"
    ON shifts FOR UPDATE
    TO authenticated
    USING (auth.uid() = doctor_id);

CREATE POLICY "Users can insert shifts"
    ON shifts FOR INSERT
    TO authenticated
    WITH CHECK (true);

-- Policies for shift swap requests
CREATE POLICY "Users can read their swap requests"
    ON shift_swap_requests FOR SELECT
    TO authenticated
    USING (
        auth.uid() = requesting_doctor_id OR 
        auth.uid() = requested_doctor_id
    );

CREATE POLICY "Users can create swap requests"
    ON shift_swap_requests FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = requesting_doctor_id);

CREATE POLICY "Users can update their swap requests"
    ON shift_swap_requests FOR UPDATE
    TO authenticated
    USING (
        auth.uid() = requesting_doctor_id OR 
        auth.uid() = requested_doctor_id
    );