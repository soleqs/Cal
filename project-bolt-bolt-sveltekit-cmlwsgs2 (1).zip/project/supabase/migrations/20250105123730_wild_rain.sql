/*
  # Add user roles and permissions

  1. Changes
    - Add role enum type
    - Add role column to profiles table
    - Update RLS policies for role-based access
  
  2. Security
    - Add policies for different role permissions
*/

-- Create role enum
CREATE TYPE user_role AS ENUM ('admin', 'head_nurse', 'nurse', 'orderly');

-- Add role column to profiles
ALTER TABLE profiles 
ADD COLUMN role user_role NOT NULL DEFAULT 'nurse';

-- Update shifts policies for role-based access
CREATE POLICY "Admins and head nurses can modify all shifts"
    ON shifts FOR ALL
    TO authenticated
    USING (
        auth.uid() IN (
            SELECT id FROM profiles 
            WHERE role IN ('admin', 'head_nurse')
        )
    );

-- Allow users to view all profiles
CREATE POLICY "Users can view all profiles"
    ON profiles FOR SELECT
    TO authenticated
    USING (true);

-- Only admins can modify roles
CREATE POLICY "Only admins can modify roles"
    ON profiles FOR UPDATE
    TO authenticated
    USING (
        auth.uid() IN (
            SELECT id FROM profiles 
            WHERE role = 'admin'
        )
    )
    WITH CHECK (
        auth.uid() IN (
            SELECT id FROM profiles 
            WHERE role = 'admin'
        )
    );