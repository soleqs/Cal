<script>
  import { onMount } from 'svelte';
  import { supabase } from '$lib/supabaseClient';
  import { language } from '$lib/stores';

  let users = [];
  let loading = true;
  let userRole = null;

  async function updateUserRole(userId, newRole) {
    const { error } = await supabase
      .from('profiles')
      .update({ role: newRole })
      .eq('id', userId);
    
    if (!error) {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .order('role');
      users = data;
    }
  }

  onMount(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      const { data: profileData } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', session.user.id)
        .single();
      userRole = profileData?.role;

      if (userRole === 'admin') {
        const { data } = await supabase
          .from('profiles')
          .select('*')
          .order('role');
        users = data;
      }
    }
    loading = false;
  });

  const roles = [
    { value: 'admin', labelRu: 'Администратор', labelCz: 'Administrátor' },
    { value: 'head_nurse', labelRu: 'Старшая медсестра', labelCz: 'Vrchní sestra' },
    { value: 'nurse', labelRu: 'Медсестра', labelCz: 'Zdravotní sestra' },
    { value: 'orderly', labelRu: 'Санитар', labelCz: 'Sanitář' }
  ];
</script>

<div class="max-w-4xl mx-auto mt-8 bg-white rounded-lg shadow-xl p-6">
  <h1 class="text-2xl font-bold mb-6">
    {$language === 'ru' ? 'Панель администратора' : 'Administrátorský panel'}
  </h1>

  {#if loading}
    <p class="text-center text-gray-600">
      {$language === 'ru' ? 'Загрузка...' : 'Načítání...'}
    </p>
  {:else if userRole === 'admin'}
    <div class="overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200">
        <thead>
          <tr>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Email
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              {$language === 'ru' ? 'Роль' : 'Role'}
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              {$language === 'ru' ? 'Действия' : 'Akce'}
            </th>
          </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
          {#each users as user}
            <tr>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {user.email}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {user.role === 'admin' ? ($language === 'ru' ? 'Администратор' : 'Administrátor') :
                 user.role === 'head_nurse' ? ($language === 'ru' ? 'Старшая медсестра' : 'Vrchní sestra') :
                 user.role === 'nurse' ? ($language === 'ru' ? 'Медсестра' : 'Zdravotní sestra') :
                 ($language === 'ru' ? 'Санитар' : 'Sanitář')}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                <select
                  value={user.role}
                  on:change={(e) => updateUserRole(user.id, e.target.value)}
                  class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                >
                  {#each roles as role}
                    <option value={role.value}>
                      {$language === 'ru' ? role.labelRu : role.labelCz}
                    </option>
                  {/each}
                </select>
              </td>
            </tr>
          {/each}
        </tbody>
      </table>
    </div>
  {:else}
    <p class="text-center text-red-600">
      {$language === 'ru' ? 'Доступ запрещен' : 'Přístup odepřen'}
    </p>
  {/if}
</div>