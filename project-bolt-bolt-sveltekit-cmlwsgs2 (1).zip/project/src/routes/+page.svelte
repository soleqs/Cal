<script>
  import { onMount } from 'svelte';
  import { format, startOfMonth, endOfMonth, eachDayOfInterval, isToday } from 'date-fns';
  import { ru, cs } from 'date-fns/locale';
  import { language } from '$lib/stores';
  import { isHoliday } from '$lib/holidays';

  let currentDate = new Date();
  let days = [];

  $: {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    days = eachDayOfInterval({ start, end });
  }

  $: locale = $language === 'ru' ? ru : cs;

  function previousMonth() {
    currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1);
  }

  function nextMonth() {
    currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1);
  }

  $: weekDays = $language === 'ru' 
    ? ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
    : ['Po', 'Út', 'St', 'Čt', 'Pá', 'So', 'Ne'];
</script>

<div class="bg-white/90 rounded-lg shadow-xl p-6 my-4">
  <div class="mb-4 flex items-center justify-between">
    <div class="flex gap-4 items-center">
      <button
        class="p-2 rounded-full hover:bg-gray-100"
        on:click={previousMonth}
      >
        ←
      </button>
      <span class="text-xl font-semibold">
        {format(currentDate, 'LLLL yyyy', { locale })}
      </span>
      <button
        class="p-2 rounded-full hover:bg-gray-100"
        on:click={nextMonth}
      >
        →
      </button>
    </div>
  </div>

  <div class="grid grid-cols-7 gap-2">
    {#each weekDays as day}
      <div class="text-center font-semibold p-2 text-gray-600">{day}</div>
    {/each}

    {#each days as day}
      {@const holiday = isHoliday(day)}
      <div
        class="border rounded-lg p-2 min-h-[100px] transition-colors
          {isToday(day) ? 'bg-blue-50 border-blue-200' : ''}
          {holiday ? 'bg-red-50' : ''}"
      >
        <div class="text-right mb-2 {isToday(day) ? 'font-bold' : ''}">
          {format(day, 'd')}
        </div>
        {#if holiday}
          <div class="text-xs text-red-600 mb-2">
            {holiday.name[$language]}
          </div>
        {/if}
        <div class="space-y-1">
          <div class="text-xs bg-green-100 rounded p-1">
            {$language === 'ru' ? 'Утро' : 'Ráno'}: --
          </div>
          <div class="text-xs bg-blue-100 rounded p-1">
            {$language === 'ru' ? 'Ночь' : 'Noc'}: --
          </div>
        </div>
      </div>
    {/each}
  </div>
</div>