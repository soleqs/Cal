<script>
	import { onMount } from 'svelte';
	import { goto } from '$app/navigation';
	
	onMount(() => {
		// После успешной аутентификации перенаправляем на главную страницу
		goto('/');
	});
</script>

<div class="min-h-screen flex items-center justify-center">
	<div class="text-center">
		<h2 class="text-xl font-semibold">Выполняется вход...</h2>
		<p class="text-gray-600">Пожалуйста, подождите</p>
	</div>
</div>