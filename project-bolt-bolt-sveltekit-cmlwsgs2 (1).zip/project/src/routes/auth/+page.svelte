<script>
	import { supabase } from '$lib/supabaseClient';
	import { language } from '$lib/stores';
	import { goto } from '$app/navigation';
	
	let email = '';
	let password = '';
	let loading = false;
	let error = null;

	async function handleLogin() {
		try {
			loading = true;
			error = null;
			const { data, error: signInError } = await supabase.auth.signInWithPassword({
				email,
				password
			});
			
			if (signInError) {
				error = $language === 'ru' ? 
					'Неверный email или пароль' : 
					'Nesprávný email nebo heslo';
				return;
			}

			if (data?.user) {
				goto('/');
			}
		} catch (e) {
			error = $language === 'ru' ? 
				'Произошла ошибка при входе' : 
				'Došlo k chybě při přihlášení';
		} finally {
			loading = false;
		}
	}

	async function handleSignUp() {
		try {
			loading = true;
			error = null;
			
			// 1. Create auth user
			const { data: authData, error: signUpError } = await supabase.auth.signUp({
				email,
				password
			});
			
			if (signUpError) throw signUpError;

			if (authData?.user) {
				// 2. Create profile
				const { error: profileError } = await supabase
					.from('profiles')
					.insert([
						{
							id: authData.user.id,
							email: email,
							role: 'nurse'
						}
					]);

				if (profileError) throw profileError;

				error = $language === 'ru' ? 
					'Регистрация успешна! Теперь вы можете войти.' : 
					'Registrace úspěšná! Nyní se můžete přihlásit.';
			}
		} catch (e) {
			console.error('Signup error:', e);
			error = $language === 'ru' ? 
				'Ошибка при регистрации' : 
				'Chyba při registraci';
		} finally {
			loading = false;
		}
	}

	async function signInWithGoogle() {
		try {
			loading = true;
			error = null;
			const { error: signInError } = await supabase.auth.signInWithOAuth({
				provider: 'google',
				options: {
					redirectTo: `${window.location.origin}/auth/callback`
				}
			});
			
			if (signInError) throw signInError;
		} catch (e) {
			error = $language === 'ru' ? 
				'Ошибка при входе через Google' : 
				'Chyba při přihlášení přes Google';
		} finally {
			loading = false;
		}
	}
</script>

<!-- Rest of the template remains unchanged -->