<script>
  import '../app.css';
  import { language } from '$lib/stores';
  import { supabase } from '$lib/supabaseClient';
  import { onMount } from 'svelte';

  let user = null;
  let userRole = null;

  onMount(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    user = session?.user;
    
    if (user) {
      const { data } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .single();
      userRole = data?.role;
    }
  });

  function toggleLanguage() {
    language.update(current => current === 'ru' ? 'cz' : 'ru');
  }
</script>

<div class="min-h-screen bg-gradient-to-br from-purple-600 to-teal-800">
  <div class="container mx-auto px-4">
    <header class="py-4 flex justify-between items-center">
      <nav class="flex items-center space-x-6">
        <a href="/" class="text-white hover:text-gray-200">
          {$language === 'ru' ? 'Главная' : 'Hlavní'}
        </a>
        {#if user}
          <a href="/profile" class="text-white hover:text-gray-200">
            {$language === 'ru' ? 'Профиль' : 'Profil'}
          </a>
          <a href="/users" class="text-white hover:text-gray-200">
            {$language === 'ru' ? 'Пользователи' : 'Uživatelé'}
          </a>
          {#if userRole === 'admin'}
            <a href="/admin" class="text-white hover:text-gray-200">
              {$language === 'ru' ? 'Админ панель' : 'Admin panel'}
            </a>
          {/if}
        {:else}
          <a href="/auth" class="text-white hover:text-gray-200">
            {$language === 'ru' ? 'Войти' : 'Přihlásit se'}
          </a>
        {/if}
      </nav>
      
      <div class="flex items-center space-x-4">
        <button
          on:click={toggleLanguage}
          class="px-4 py-2 bg-white/20 text-white rounded-lg hover:bg-white/30 transition-colors"
        >
          {$language === 'ru' ? 'CZ' : 'RU'}
        </button>
        
        {#if user}
          <button
            on:click={() => supabase.auth.signOut()}
            class="px-4 py-2 bg-red-500/20 text-white rounded-lg hover:bg-red-500/30 transition-colors"
          >
            {$language === 'ru' ? 'Выйти' : 'Odhlásit se'}
          </button>
        {/if}
      </div>
    </header>
    
    <main>
      <slot />
    </main>
  </div>
</div>