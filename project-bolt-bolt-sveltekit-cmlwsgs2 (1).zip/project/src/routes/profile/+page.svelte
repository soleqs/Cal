<script>
  import { onMount } from 'svelte';
  import { supabase } from '$lib/supabaseClient';
  import { language } from '$lib/stores';

  let profile = null;
  let loading = true;

  onMount(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', session.user.id)
        .single();
      profile = data;
    }
    loading = false;
  });
</script>

<div class="max-w-2xl mx-auto mt-8 bg-white rounded-lg shadow-xl p-6">
  {#if loading}
    <p class="text-center text-gray-600">
      {$language === 'ru' ? 'Загрузка...' : 'Načítání...'}
    </p>
  {:else if profile}
    <h1 class="text-2xl font-bold mb-6">
      {$language === 'ru' ? 'Личный кабинет' : 'Osobní účet'}
    </h1>
    
    <div class="space-y-4">
      <div>
        <label class="block text-sm font-medium text-gray-700">
          {$language === 'ru' ? 'Email' : 'Email'}
        </label>
        <p class="mt-1 text-gray-900">{profile.email}</p>
      </div>
      
      <div>
        <label class="block text-sm font-medium text-gray-700">
          {$language === 'ru' ? 'Роль' : 'Role'}
        </label>
        <p class="mt-1 text-gray-900">
          {profile.role === 'admin' ? ($language === 'ru' ? 'Администратор' : 'Administrátor') :
           profile.role === 'head_nurse' ? ($language === 'ru' ? 'Старшая медсестра' : 'Vrchní sestra') :
           profile.role === 'nurse' ? ($language === 'ru' ? 'Медсестра' : 'Zdravotní sestra') :
           ($language === 'ru' ? 'Санитар' : 'Sanitář')}
        </p>
      </div>
    </div>
  {:else}
    <p class="text-center text-red-600">
      {$language === 'ru' ? 'Необходимо войти в систему' : 'Přihlášení je povinné'}
    </p>
  {/if}
</div>