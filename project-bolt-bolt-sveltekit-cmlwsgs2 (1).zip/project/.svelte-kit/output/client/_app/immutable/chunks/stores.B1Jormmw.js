import{w as a}from"./index.D5LuVPLO.js";const o=a("ru");export{o as l};
