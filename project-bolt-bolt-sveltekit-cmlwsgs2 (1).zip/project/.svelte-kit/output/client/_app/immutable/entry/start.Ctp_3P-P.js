import{a as t}from"../chunks/entry.NEok9Js9.js";export{t as start};
