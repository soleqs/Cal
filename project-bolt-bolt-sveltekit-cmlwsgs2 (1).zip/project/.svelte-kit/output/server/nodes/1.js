

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.B7C127DH.js","_app/immutable/chunks/scheduler.BjFDxd0B.js","_app/immutable/chunks/index.BSZ_U2fO.js","_app/immutable/chunks/entry.NEok9Js9.js","_app/immutable/chunks/index.D5LuVPLO.js"];
export const stylesheets = [];
export const fonts = [];
