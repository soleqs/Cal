

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/auth/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.C8X8kc4P.js","_app/immutable/chunks/scheduler.BjFDxd0B.js","_app/immutable/chunks/index.BSZ_U2fO.js","_app/immutable/chunks/supabaseClient.DQQnOVFa.js","_app/immutable/chunks/preload-helper.C1FmrZbK.js","_app/immutable/chunks/stores.B1Jormmw.js","_app/immutable/chunks/index.D5LuVPLO.js","_app/immutable/chunks/entry.NEok9Js9.js"];
export const stylesheets = [];
export const fonts = [];
