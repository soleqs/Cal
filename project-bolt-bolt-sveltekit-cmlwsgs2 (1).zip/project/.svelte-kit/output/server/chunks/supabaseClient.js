import { createClient } from "@supabase/supabase-js";
createClient(
  "https://bszntqrwngzatzatyfhv.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJzem50cXJ3bmd6YXR6YXR5Zmh2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzYwODAyOTYsImV4cCI6MjA1MTY1NjI5Nn0.6rqeQTFabxlwht6_Zkwxq-UdNkkPIjGGqDq1rO4Cm6g"
);
