import { w as writable } from "./index.js";
const language = writable("ru");
export {
  language as l
};
