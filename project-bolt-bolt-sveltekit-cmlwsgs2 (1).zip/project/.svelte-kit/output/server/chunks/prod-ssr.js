const DEV = false;
export {
  DEV as D
};
