import { D as DEV } from "../../../chunks/prod-ssr.js";
const dev = DEV;
const csr = dev;
const prerender = true;
export {
  csr,
  prerender
};
