import { c as create_ssr_component, a as subscribe, e as escape } from "../../../chunks/ssr.js";
import "../../../chunks/supabaseClient.js";
import { l as language } from "../../../chunks/stores.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  $$unsubscribe_language();
  return `<div class="max-w-4xl mx-auto mt-8 bg-white rounded-lg shadow-xl p-6"><h1 class="text-2xl font-bold mb-6">${escape($language === "ru" ? "Панель администратора" : "Administrátorský panel")}</h1> ${`<p class="text-center text-gray-600">${escape($language === "ru" ? "Загрузка..." : "Načítání...")}</p>`}</div>`;
});
export {
  Page as default
};
