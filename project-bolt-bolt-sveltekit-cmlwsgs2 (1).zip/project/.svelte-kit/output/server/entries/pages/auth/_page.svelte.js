import { c as create_ssr_component, a as subscribe } from "../../../chunks/ssr.js";
import "../../../chunks/supabaseClient.js";
import { l as language } from "../../../chunks/stores.js";
import "../../../chunks/client.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => value);
  $$unsubscribe_language();
  return ``;
});
export {
  Page as default
};
