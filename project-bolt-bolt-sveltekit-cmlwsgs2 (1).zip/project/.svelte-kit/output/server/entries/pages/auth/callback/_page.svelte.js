import { c as create_ssr_component } from "../../../../chunks/ssr.js";
import "../../../../chunks/client.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `<div class="min-h-screen flex items-center justify-center" data-svelte-h="svelte-66jxfs"><div class="text-center"><h2 class="text-xl font-semibold">Выполняется вход...</h2> <p class="text-gray-600">Пожалуйста, подождите</p></div></div>`;
});
export {
  Page as default
};
