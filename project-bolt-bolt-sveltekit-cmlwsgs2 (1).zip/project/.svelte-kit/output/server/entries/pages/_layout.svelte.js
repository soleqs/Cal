import { c as create_ssr_component, a as subscribe, e as escape } from "../../chunks/ssr.js";
import { l as language } from "../../chunks/stores.js";
import "../../chunks/supabaseClient.js";
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  $$unsubscribe_language();
  return `<div class="min-h-screen bg-gradient-to-br from-purple-600 to-teal-800"><div class="container mx-auto px-4"><header class="py-4 flex justify-between items-center"><nav class="flex items-center space-x-6"><a href="/" class="text-white hover:text-gray-200">${escape($language === "ru" ? "Главная" : "Hlavní")}</a> ${`<a href="/auth" class="text-white hover:text-gray-200">${escape($language === "ru" ? "Войти" : "Přihlásit se")}</a>`}</nav> <div class="flex items-center space-x-4"><button class="px-4 py-2 bg-white/20 text-white rounded-lg hover:bg-white/30 transition-colors">${escape($language === "ru" ? "CZ" : "RU")}</button> ${``}</div></header> <main>${slots.default ? slots.default({}) : ``}</main></div></div>`;
});
export {
  Layout as default
};
