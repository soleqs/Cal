import { c as create_ssr_component, a as subscribe, e as escape, b as each, d as add_attribute } from "../../../chunks/ssr.js";
import "../../../chunks/supabaseClient.js";
import { l as language } from "../../../chunks/stores.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  const roles = [
    {
      value: "all",
      labelRu: "Все",
      labelCz: "Všichni"
    },
    {
      value: "admin",
      labelRu: "Администратор",
      labelCz: "Administrátor"
    },
    {
      value: "head_nurse",
      labelRu: "Старшая медсестра",
      labelCz: "Vrchní sestra"
    },
    {
      value: "nurse",
      labelRu: "Медсестра",
      labelCz: "Zdravotní sestra"
    },
    {
      value: "orderly",
      labelRu: "Санитар",
      labelCz: "Sanitář"
    }
  ];
  $$unsubscribe_language();
  return `<div class="max-w-4xl mx-auto mt-8 bg-white rounded-lg shadow-xl p-6"><h1 class="text-2xl font-bold mb-6">${escape($language === "ru" ? "Список пользователей" : "Seznam uživatelů")}</h1> <div class="mb-6"><label class="block text-sm font-medium text-gray-700 mb-2">${escape($language === "ru" ? "Фильтр по должности" : "Filtr podle pozice")}</label> <select class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">${each(roles, (role) => {
    return `<option${add_attribute("value", role.value, 0)}>${escape($language === "ru" ? role.labelRu : role.labelCz)} </option>`;
  })}</select></div> ${`<p class="text-center text-gray-600">${escape($language === "ru" ? "Загрузка..." : "Načítání...")}</p>`}</div>`;
});
export {
  Page as default
};
