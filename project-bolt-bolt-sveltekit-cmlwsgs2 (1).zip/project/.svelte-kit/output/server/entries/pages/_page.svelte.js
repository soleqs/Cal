import { c as create_ssr_component, a as subscribe, e as escape, b as each } from "../../chunks/ssr.js";
import { startOfMonth, endOfMonth, eachDayOfInterval, format, isToday } from "date-fns";
import { ru, cs } from "date-fns/locale";
import { l as language } from "../../chunks/stores.js";
const czechHolidays = [
  { date: "01-01", name: { ru: "Новый год", cz: "Nový rok" } },
  { date: "01-05", name: { ru: "День труда", cz: "Svátek práce" } },
  { date: "05-08", name: { ru: "День Победы", cz: "Den vítězství" } },
  { date: "07-05", name: { ru: "День Кирилла и Мефодия", cz: "Den slovanských věrozvěstů Cyrila a Metoděje" } },
  { date: "07-06", name: { ru: "День Яна Гуса", cz: "Den upálení mistra Jana Husa" } },
  { date: "09-28", name: { ru: "День чешской государственности", cz: "Den české státnosti" } },
  { date: "10-28", name: { ru: "День образования Чехословакии", cz: "Den vzniku samostatného československého státu" } },
  { date: "11-17", name: { ru: "День борьбы за свободу и демократию", cz: "Den boje za svobodu a demokracii" } },
  { date: "12-24", name: { ru: "Сочельник", cz: "Štědrý den" } },
  { date: "12-25", name: { ru: "Рождество", cz: "První svátek vánoční" } },
  { date: "12-26", name: { ru: "День святого Стефана", cz: "Druhý svátek vánoční" } }
];
function isHoliday(date) {
  const monthDay = date.toLocaleDateString("en-GB", { month: "2-digit", day: "2-digit" }).split("/").reverse().join("-");
  return czechHolidays.find((holiday) => holiday.date === monthDay);
}
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let locale;
  let weekDays;
  let $language, $$unsubscribe_language;
  $$unsubscribe_language = subscribe(language, (value) => $language = value);
  let currentDate = /* @__PURE__ */ new Date();
  let days = [];
  {
    {
      const start = startOfMonth(currentDate);
      const end = endOfMonth(currentDate);
      days = eachDayOfInterval({ start, end });
    }
  }
  locale = $language === "ru" ? ru : cs;
  weekDays = $language === "ru" ? ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"] : ["Po", "Út", "St", "Čt", "Pá", "So", "Ne"];
  $$unsubscribe_language();
  return `<div class="bg-white/90 rounded-lg shadow-xl p-6 my-4"><div class="mb-4 flex items-center justify-between"><div class="flex gap-4 items-center"><button class="p-2 rounded-full hover:bg-gray-100" data-svelte-h="svelte-1xyz85b">←</button> <span class="text-xl font-semibold">${escape(format(currentDate, "LLLL yyyy", { locale }))}</span> <button class="p-2 rounded-full hover:bg-gray-100" data-svelte-h="svelte-1y8m6qt">→</button></div></div> <div class="grid grid-cols-7 gap-2">${each(weekDays, (day) => {
    return `<div class="text-center font-semibold p-2 text-gray-600">${escape(day)}</div>`;
  })} ${each(days, (day) => {
    let holiday = isHoliday(day);
    return ` <div class="${"border rounded-lg p-2 min-h-[100px] transition-colors " + escape(isToday(day) ? "bg-blue-50 border-blue-200" : "", true) + " " + escape(holiday ? "bg-red-50" : "", true)}"><div class="${"text-right mb-2 " + escape(isToday(day) ? "font-bold" : "", true)}">${escape(format(day, "d"))}</div> ${holiday ? `<div class="text-xs text-red-600 mb-2">${escape(holiday.name[$language])} </div>` : ``} <div class="space-y-1"><div class="text-xs bg-green-100 rounded p-1">${escape($language === "ru" ? "Утро" : "Ráno")}: --</div> <div class="text-xs bg-blue-100 rounded p-1">${escape($language === "ru" ? "Ночь" : "Noc")}: --
          </div></div> </div>`;
  })}</div></div>`;
});
export {
  Page as default
};
